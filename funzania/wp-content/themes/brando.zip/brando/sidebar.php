<?php
/**
 * The sidebar containing the main widget area
 *
 * @package Brando
 */
?>
<?php
	brando_get_sidebar();
?>