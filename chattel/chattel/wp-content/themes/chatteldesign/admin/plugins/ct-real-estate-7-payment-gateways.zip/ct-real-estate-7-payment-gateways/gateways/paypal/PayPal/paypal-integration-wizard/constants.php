<?php

	$user = "jb-us-seller_api1.paypal.com";
	$password = "WX4WTU3S8MY44S7F";
	$signature = "AFcWxV21C7fd0v3bYYYRCpSSRl31A7yDhhsPUU2XhtMoZXsWHFxu-RWy";
	
	
//china acc
	// $user = "vimchina_api1.gmail.com";
	// $password = "89HKVC3PKU7P5C7Q";
// $signature = "AFcWxV21C7fd0v3bYYYRCpSSRl31AopnfVbWRQBsOH478G1q-ZOFDY3d";




	// $user ="vimalnath53-facilitator_api1.gmail.com";
	// $password ="E8CACKS59N8JKC8M";
	// $signature ="Ai1PaghZh5FmBLCDCTQpwG8jB264AB54Ur8zxYwAjKZX1edng6vji926";
// $app_id = 'APP-91B98039N55382502';
// PayPal Sandbox URL
// $PAYPAL_URL= "https://www.sandbox.paypal.com/incontext?token=";
// PayPal Sandbox endpoint
// $url = "https://api-3t.sandbox.paypal.com/nvp";


	// $user = "klmtstest_api1.gmail.com";
	// $password = "D787CJAKV89TBYSQ";
	// $signature = "AFcWxV21C7fd0v3bYYYRCpSSRl31A-0ldTk60zTTb33Kt0BM0xiuR7wW";
// $app_id = 'APP-80W284485P519543T';
// PayPal Sandbox URL
// $PAYPAL_URL= "https://www.sandbox.paypal.com/incontext?token=";
// PayPal Sandbox endpoint
// $url = "https://api-3t.sandbox.paypal.com/nvp";

